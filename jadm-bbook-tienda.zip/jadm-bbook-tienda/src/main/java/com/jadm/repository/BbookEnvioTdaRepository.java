package com.jadm.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.jadm.model.BbookEnvioTda;

@Repository
public interface BbookEnvioTdaRepository extends CrudRepository<BbookEnvioTda, String> {

	@Modifying(clearAutomatically = true)
	@Query(value = "update app_sam.sdi_sdiorgmst s set s.download_date_1 = sysdate, s.observacion = :responses where rowid = :id", nativeQuery = true)
    public void uopdSdiSdiOrgmst(@Param("id") String id, @Param("responses") String responses);	
	
}
